old = int(input("Nhập năm sinh: "))
a = 2025 - old
if a >= 18:
    print(f"Tuổi hiện tại là: {a}")
    print("Người đó đã đủ 18 tuổi")
else:
    print(f"Tuổi hiện tại là: {a}")
    print("Người đó chưa đủ 18 tuổi")
    