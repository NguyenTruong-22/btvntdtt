character = input("Nhập vào một kí tự: ")
if len(character) != 1:
    print("Vui lòng nhập 1 kí tự")
elif 65 <= ord(character) <= 90:
    a = ord(character) + 32
    print(chr(a))
elif 97 <= ord(character) <= 122:
    a = ord(character) - 32
    print(chr(a))
else:
    print("Không phải là kí tự alphabet")