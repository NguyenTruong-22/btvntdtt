a = int(input("Nhập năm sinh: "))
if 2025 - a >= 18:
    print("Bạn đã đủ tuổi đi bầu cử")
else:
    print("Bạn chưa đủ tuổi đi bầu cử")