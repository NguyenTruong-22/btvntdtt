x = int(input("Nhập  một số nguyên từ 0 đến 9: "))
match x:
    case 0:
        print("Không")
match x:
    case 1:
        print("Một")
match x:
    case 2:
        print("Hai")
match x:
    case 3:
        print("Ba")
match x:
    case 4:
        print("Bốn")
match x:
    case 5:
        print("Năm")
match x:
    case 6:
        print("Sáu")
match x:
    case 7:
        print("Bảy")
match x:
    case 8:
        print("Tám")
match x:
    case 9:
        print("Chín")