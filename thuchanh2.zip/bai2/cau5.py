nhap_so = input("Nhập 2 số ( cách nhau bằng dấu cách ): ").split()
a,b = map(float,nhap_so)
if a > b:
    print(a)
elif a < b:
    print(b)
else:
    print("Hai số bằng nhau")