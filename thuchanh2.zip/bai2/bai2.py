a = float(input("Nhập chiều rộng a: "))
b = float(input("Nhập chiều dài b: "))
s = a*b - 3.14*(a/2)**2
print(f"{s:.1f}")