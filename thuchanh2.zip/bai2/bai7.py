row = input("Nhập dãy kí tự: ")
print("Chữ cái thứ năm là: " + row[4])
print("Chữ cái thứ chín là: " + row[8])