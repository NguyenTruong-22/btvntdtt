a = int(input("Nhập một số nguyên: "))
if a % 5 == 0 and a % 2 != 0:
    print("True")
else:
    print("False")