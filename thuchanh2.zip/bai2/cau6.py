character = input("Nhập một ký tự: ")
if 65 <= ord(character) <= 90 or 92 <= ord(character) <= 122:
    print(f"{character} là một ký tự")
else:
    print(f"{character} là một số")