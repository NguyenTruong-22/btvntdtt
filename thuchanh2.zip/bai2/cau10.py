score = float(input("Nhập điểm: "))
if score >= 4:
    print("Qua môn")
else:
    print("Học lại")