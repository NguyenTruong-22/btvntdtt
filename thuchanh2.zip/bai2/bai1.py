n = int(input("Nhập số nguyên n: "))
print(n*2)
