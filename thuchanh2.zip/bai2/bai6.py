a, b, c = map(float,input("Nhập lần lượt 3 cạnh của tam giác (cách nhau bằng dấu cách): ").split())
if a + b > c and a + c > b and b + c > a:
    print("Đây là các cạnh của 1 tam giác")
    p = ( a + b + c ) / 2
    import math
    S = math.sqrt(p*(p-a)*(p-b)*(p-c))
    print(f"Diện tích của tam giác đó là: {S:.1f}")
else:
    print("Khong phai 3 canh cua tam giac")
