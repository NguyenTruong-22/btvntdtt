score = float(input("Nhập điểm: "))
if score >= 8:
    print("Học lực giỏi")
elif 8 > score >= 6.5:
    print("Học lực khá")
elif 6.5 > score >= 5:
    print("Học lực trung bình")
else:
    print("Học lực yếu")