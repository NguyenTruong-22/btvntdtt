A = input("Nhập chữ cái hoa: ")
if len(A) != 1:
    print("Vui lòng nhập 1 kí tự")
elif ord(A) == 65:
    print(f"'{A}' là đặc biệt")
elif 65 < ord(A) <= 90:
    C = ord(A) + 32
    B = ord(A) + 31
    D = chr(C)
    E = chr(B)
    print(f"Chữ cái thường liền trước chữ cái {D} tương ứng của {A} là: {E}")
else:
    print(f"Vui lòng nhập đúng chữ in hoa")