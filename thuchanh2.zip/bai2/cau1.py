a = int(input("Nhập một số nguyên: "))
if a % 2 == 0:
    print(f"{a} là số chẵn")
else:
    print(f"{a} là số lẻ")
    