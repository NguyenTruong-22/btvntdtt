character =  input("Nhập vào một 'kí tự': ")
if 65 <= ord(character) <= 90 and 92 <= ord(character) <= 122:
    print(f"{{{character}}} là kí tự alphabet")
else:
    print(f"{{{character}}} là kí tự alphabet")