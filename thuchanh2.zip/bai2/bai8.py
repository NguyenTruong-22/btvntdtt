name = input("Ten chu ho: ")
a = int(input("Chi so thang truoc: "))
b = int(input("Chi so thang nay: "))
print(f"Ho va ten: {name}")
if b - a <= 50:
    c = (b - a)*1984*1.08
    print(f"Tien phai tra la: {c:.0f}")
elif 50 < b - a <= 100:
    c = ((b - a - 50)*2050 + 50 * 1984)*1.08
    print(f"Tien phai tra la: {c:.0f}")
elif 100 < b - a <= 200:
    c = ((b - a - 100)*2380 + 50*2050 + 50 * 1984)*1.08
    print(f"Tien phai tra la: {c:.0f}")
elif 200 < b - a <= 300:
    c = ((b - a - 200)*2998 + 100*2380 + 50*2050 + 50 * 1984)*1.08
    print(f"Tien phai tra la: {c:.0f}")
elif 300 < b - a <= 400:
    c = ((b - a - 300)*3350 + 100*2998+ 100*2380 + 50*2050 + 50 * 1984)*1.08
    print(f"Tien phai tra la: {c:.0f}")
elif 400 < b - a:
    c = ((b - a - 400)*3460 + 100*3350 + 100*2998 + 100*2380 + 50*2050 + 50 * 1984)*1.08
    print(f"Tien phai tra la: {c:.0f}")
else:
    print("Vui lòng nhập đúng")


    