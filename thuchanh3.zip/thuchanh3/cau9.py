a, b, c, d = map(int,input("Nhập 4 số nguyên( cách nhau bằng dấu cách): ").split())
if a > b and a > c and a > d:
    print("Số nguyên lớn nhất trong 4 số là: ",a)
elif b > a and b > c and b > d:
    print("Số nguyên lớn nhất trong 4 số là: ",b)
elif c > a and c > b and c > d:
    print("Số nguyên lớn nhất trong 4 số là: ",c)
else:
    print("Số nguyên lớn nhất trong 4 số là: ",d)