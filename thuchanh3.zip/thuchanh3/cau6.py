a = int(input("Nhập số nguyên a: "))
b = int(input("Nhập số nguyên b: "))
if a < 0 and b < 0:
    print("Yes")
else:
    print("No")