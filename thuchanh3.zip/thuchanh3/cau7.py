a = input("Nhập chuỗi a: ")
b = input("Nhập chuỗi b: ")
if len(a) > len(b):
    print("True")
else:
    print("False")