x = int(input("Nhập một số nguyên dương: "))
if x % 2 == 0:
    print("Even")
else:
    print("Odd")