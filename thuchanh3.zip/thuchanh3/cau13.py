a, b = map(float,input("Nhập 2 số thực a và b( cách nhau bằng dấu cách ): ").split())
if a == b == 0:
    print("Vô số nghiệm")
elif a == 0 != b:
    print("Vô nghiệm")
else:
    print(f"{-b/a:.2f}")