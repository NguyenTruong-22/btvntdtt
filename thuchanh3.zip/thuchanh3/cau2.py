a, b = input("Nhập 2 số( cách nhau bằng dấu cách): ").split()
a = int(a)
b = int(b)
a = a^b
b = a^b
a = a^b
print(a, b)

