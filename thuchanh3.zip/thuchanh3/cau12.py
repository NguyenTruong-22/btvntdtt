a = int(input("Nhập số kWh: "))
if a <= 50:
    b = a * 1500
    print("Tiền điện: ",b)
elif 50 < a <= 100:
    b = 50 * 1500 + (a - 50) * 2000
    print("Tiền điện: ",b)
elif a > 100:
    b = 50*1500 + 50*20001 +(a-100)*3000
    print("Tiền điện: ",b)
else:
    print("Vui lòng nhập lai")