a = float(input("Nhập một số thực: "))
ceil = " "
floor =" "
rounds = " "
if a == int (a):
    ceil = floor = rounds = a
    print(ceil, floor, rounds)
elif a > 0:
    ceil = int(a) + 1
    floor = int(a)
    if a - int(a) >= 0.5:
        rounds = int(a) + 1
    else:
        rounds = int(a)
    print(ceil, floor, rounds)
else:
    ceil = int(a)
    floor = int(a) - 1 
    if a - int(a) <= -0.5:
        rounds = int(a) - 1
    else:
        rounds = int(a)
    print(ceil, floor, rounds)