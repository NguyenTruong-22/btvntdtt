a = input("Nhập một số nguyên n: ")
reverse = " "
for i in a:
    reverse = i + reverse
print(reverse)