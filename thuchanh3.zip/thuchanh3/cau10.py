a, b, c = map(int,input("Nhập 3 số nguyên dương( cách nhau bằng dấu cách): ").split())
if a == b == c != 0:
    print("Tam giác đều")
elif a == b != c or a == c != b or a != b == c:
    print("Tam giác cân")
elif a + b > c and a + c > b and b + c > a:
    print("Tam giác thường")
else:
    print("Không phải tam giác")