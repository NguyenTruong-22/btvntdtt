a = int(input("Nhập số a: "))
b = int(input("Nhập số b: "))
c = int(input("Nhập số c: "))
if a + b > c and a + c > b and b + c > a:
    print("Yes")
else:
    print("No")
