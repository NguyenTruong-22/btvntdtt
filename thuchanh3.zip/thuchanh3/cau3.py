m = float(input("Nhập số m: "))
n = float(input("Nhấp số n: "))
a = m / n
import math
print(math.floor(a))